define(function() {var keywords=[{w:"Accessing",p:["p0"]},{w:"the",p:["p0","p6","p7","p10"]},{w:"Grafana",p:["p0","p6","p8","p10","p14"]},{w:"dashboard",p:["p0","p5"]},{w:"Introduction",p:["p1"]},{w:"to",p:["p1","p2"]},{w:"Alerts",p:["p1"]},{w:"Applying",p:["p2"]},{w:"visualization",p:["p2","p14"]},{w:"RMF",p:["p2","p3","p5","p10","p11","p13","p14"]},{w:"data",p:["p2","p3","p9"]},{w:"Creating",p:["p3"]},{w:"sources",p:["p3"]},{w:"Context",p:["p4"]},{w:"Sensitive",p:["p4"]},{w:"Help",p:["p4"]},{w:"master",p:["p5"]},{w:"Defining",p:["p6"]},{w:"server",p:["p6"]},{w:"Error",p:["p7"]},{w:"reporting",p:["p7"]},{w:"in",p:["p7","p14"]},{w:"plugin",p:["p7","p10"]},{w:"through",p:["p8"]},{w:"IBM",p:["p8","p11"]},{w:"z/OS",p:["p8","p10"]},{w:"Management",p:["p8"]},{w:"Facility",p:["p8"]},{w:"Historical",p:["p9"]},{w:"collection",p:["p9"]},{w:"Installing",p:["p10"]},{w:"for",p:["p10"]},{w:"on",p:["p10"]},{w:"query",p:["p11","p13"]},{w:"languages",p:["p11"]},{w:"Release",p:["p12"]},{w:"notes",p:["p12"]},{w:"Variable",p:["p13"]},{w:"syntax",p:["p13"]},{w:"of",p:["p14"]},{w:"Monitor",p:["p14"]},{w:"III",p:["p14"]},{w:"metrics",p:["p14"]}];
var ph={};
ph["p0"]=[0, 1, 2, 3];
ph["p1"]=[4, 5, 6];
ph["p2"]=[7, 8, 5, 9, 10];
ph["p3"]=[11, 9, 10, 12];
ph["p4"]=[13, 14, 15];
ph["p5"]=[9, 16, 3];
ph["p6"]=[17, 1, 2, 18];
ph["p7"]=[19, 20, 21, 1, 22];
ph["p8"]=[2, 23, 24, 25, 26, 27];
ph["p9"]=[28, 10, 29];
ph["p10"]=[30, 1, 9, 31, 25, 22, 32, 2];
ph["p12"]=[35, 36];
ph["p11"]=[24, 9, 33, 34];
ph["p14"]=[8, 39, 9, 40, 41, 42, 21, 2];
ph["p13"]=[9, 37, 33, 38];
     return {
         keywords: keywords,
         ph: ph
     }
});
