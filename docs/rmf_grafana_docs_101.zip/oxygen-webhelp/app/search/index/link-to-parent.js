/*Maps current topic to its parent: "topicIndex:parentIndex". -1 represents the map.*/
define(function () {
return {0:8,8:-1,14:-1,12:-1,10:-1,1:-1,11:-1,7:-1,6:8,3:-1,2:-1,5:-1,9:-1,13:-1};
});